/**
 * Carga el menú y gestiona el comportamiento responsive
 */
function loadMenu() {
    fetch('menu.html')
        .then(response => {
            if (!response.ok) throw new Error('Error al cargar el menú');
            return response.text();
        })
        .then(html => {
            document.getElementById('menu').innerHTML = html;
            setupMenuBehavior();
            setupScrollAnimations();
        })
        .catch(error => {
            console.error('Error:', error);
            loadMenuFallback();
        });
}

/**
 * Configura el comportamiento del menú hamburguesa
 */
function setupMenuBehavior() {
    const hamburgerBtn = document.querySelector('.hamburger-btn');
    const navLinks = document.querySelector('.nav-links');
    const mobileOverlay = document.querySelector('.mobile-overlay');
    
    if (!hamburgerBtn || !navLinks || !mobileOverlay) return;

    // Toggle del menú móvil
    hamburgerBtn.addEventListener('click', () => {
        navLinks.classList.toggle('active');
        mobileOverlay.classList.toggle('active');
        document.body.classList.toggle('no-scroll');
    });

    // Cerrar menú al hacer clic en overlay
    mobileOverlay.addEventListener('click', () => {
        navLinks.classList.remove('active');
        mobileOverlay.classList.remove('active');
        document.body.classList.remove('no-scroll');
    });

    // Cerrar menú al seleccionar opción (mobile)
    document.querySelectorAll('.nav-links a').forEach(link => {
        link.addEventListener('click', () => {
            if (window.innerWidth <= 768) {
                navLinks.classList.remove('active');
                mobileOverlay.classList.remove('active');
                document.body.classList.remove('no-scroll');
            }
        });
    });

    // Cerrar menú al redimensionar
    window.addEventListener('resize', () => {
        if (window.innerWidth > 768) {
            navLinks.classList.remove('active');
            mobileOverlay.classList.remove('active');
            document.body.classList.remove('no-scroll');
        }
    });
}

/**
 * Configura animaciones al hacer scroll
 */
function setupScrollAnimations() {
    function revealOnScroll() {
        document.querySelectorAll(".reveal").forEach(el => {
            const revealTop = el.getBoundingClientRect().top;
            if (revealTop < window.innerHeight - 100) {
                el.classList.add("active");
            }
        });
    }

    window.addEventListener("scroll", revealOnScroll);
    window.addEventListener("load", revealOnScroll);
}

/**
 * Carga un menú básico si falla la carga del principal
 */
function loadMenuFallback() {
    document.getElementById('menu').innerHTML = `
        <header class="menu">
            <div class="menu-container">
                <div class="logo">
                    <span>SecondIA</span>
                </div>
                <nav class="nav-links">
                    <a href="inicio.html">Home</a>
                    <a href="productosCatalogo.html">Productos</a>
                </nav>
            </div>
        </header>
    `;
    setupScrollAnimations();
}

// Iniciar carga del menú cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', loadMenu);