// footer.js
$(document).ready(function() {
    // 1. Cargar el footer dinámicamente
    $("#footer").load("footer.html", function(response, status) {
      if (status === "success") {
        console.log("Footer cargado correctamente");
        
        // 2. Actualizar el año de copyright
        const currentYear = new Date().getFullYear();
        $(".footer-legal p").html(`&copy; ${currentYear} SecondIA. Todos los derechos reservados.`);

      // Inicializar tooltips si los hay
      $('[data-toggle="tooltip"]').tooltip();
      /*
      // Animaciones de scroll para los elementos reveal del footer
      const footerReveals = document.querySelectorAll('#footer .reveal');
      
      function animateFooter() {
        footerReveals.forEach((element) => {
          const elementTop = element.getBoundingClientRect().top;
          const windowHeight = window.innerHeight;
          
          if (elementTop < windowHeight - 100) {
            element.classList.add('active');
          }
        });
      }
      
      // Ejecutar al cargar y al hacer scroll
      animateFooter();
      window.addEventListener('scroll', animateFooter);
      */
    }
    });
  });