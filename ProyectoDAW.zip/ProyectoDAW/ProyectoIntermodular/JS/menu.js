// Cargar el menú desde un archivo HTML externo
fetch('menu.html')
    .then(response => {
        if (!response.ok) {
            throw new Error('Error al cargar el menú: ' + response.statusText);
        }
        return response.text();
    })
    .then(data => {
        document.getElementById('menu').innerHTML = data;
    })
    .catch(error => {
        console.error('Error:', error);
    });